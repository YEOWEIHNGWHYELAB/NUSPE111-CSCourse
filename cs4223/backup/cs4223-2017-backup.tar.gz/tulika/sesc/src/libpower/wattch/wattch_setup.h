#ifndef WATTCH_SETUP_H
#define WATTCH_SETUP_H

extern void wattch_setup(void);

#endif
