#define PR_GETNSHARE	14
#define PR_MAXPROCS     1
#define PR_MAXPPROCS    5
#define PR_SETEXITSIG	8
