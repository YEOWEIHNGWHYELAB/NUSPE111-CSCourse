#ifndef ORION_SETUP_H
#define ORION_SETUP_H
#include "SescConf.h"

extern void orion_setup(SConfig* SescConf) ;
#endif
