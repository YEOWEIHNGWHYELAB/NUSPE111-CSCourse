#ifdef __cplusplus
extern "C" {
#endif
#ifndef ORRESULT_H
#define ORRESULT_H

struct orResult{
  double totEnergy ;
  double bufEnergy ;
  double switchEnergy ;
  double arbEnergy ;
};
#endif
#ifdef __cplusplus
}
#endif
