#define COMPOPTS " -DPACKAGE_NAME=\"esesc\" -DPACKAGE_TARNAME=\"esesc\" -DPACKAGE_VERSION=\"2\" -DPACKAGE_STRING=\"esesc\ 2\" -DPACKAGE_BUGREPORT=\"renau@soe.ucsc.edu\ luisceze@cs.uiuc.edu\""
