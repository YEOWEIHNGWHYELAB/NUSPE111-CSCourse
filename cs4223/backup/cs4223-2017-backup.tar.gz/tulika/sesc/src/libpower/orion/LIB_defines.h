#ifndef _LIB_DEFINES_H
#define _LIB_DEFINES_H

#include <sys/types.h>

#define LIB_Type_max_uint	u_int64_t
#define LIB_Type_max_int	int64_t

#endif	/* _LIB_DEFINES_H */
